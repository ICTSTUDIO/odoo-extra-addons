Purchase Stock Level
====================================

Show the stock level of a product in the purchase order view

If the virtual stock level is below zero the line will become red. If one of the Purchase Order lines is red the whole Order in the Tree view will become red.