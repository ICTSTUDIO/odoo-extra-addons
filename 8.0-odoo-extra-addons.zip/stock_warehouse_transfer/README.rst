.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
:alt: License: AGPL-3

Stock Warehouse Transfer
========================
Create an transfer of products between 2 warehouses. This will be done with the
use of a transit location so an incoming and outgoing picking will be created.

Bug Tracker
===========
Bugs are tracked on `GitHub Issues <https://github.com/ICTSTUDIO/8.0-extra-addons/issues>`_.

Maintainer
==========
.. image:: https://www.ictstudio.eu/github_logo.png
:alt: ICTSTUDIO
   :target: https://www.ictstudio.eu

This module is maintained by the ICTSTUDIO.